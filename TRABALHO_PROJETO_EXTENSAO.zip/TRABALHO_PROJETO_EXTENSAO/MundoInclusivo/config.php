<?php
$servidor = "localhost";
$usuario = "root";
$senha = ""; // A senha padrão no XAMPP geralmente é vazia

// Inserir o banco de dados
$banco = "mundoinclusivo";

try {
    // Conectar ao banco de dados usando XAMPP
    $pdo = new PDO("mysql:host={$servidor};dbname={$banco};port=3306;charset=utf8;", $usuario, $senha);
    
    // Configurar o PDO para lançar exceções em caso de erro
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (\Exception $e) {
    echo "<p>Erro ao se conectar no banco</p>";
    echo $e->getMessage();
}
?>