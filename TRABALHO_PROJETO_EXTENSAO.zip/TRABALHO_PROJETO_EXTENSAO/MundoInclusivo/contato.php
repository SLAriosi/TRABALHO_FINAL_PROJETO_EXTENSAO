<?php
include "header.php";
include "config.php";

// Verificar se o formulário foi enviado
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Recuperar os dados do formulário e remover espaços em branco
    $nome = trim($_POST["nome"]);
    $email = trim($_POST["email"]);
    $mensagem = trim($_POST["mensagem"]);

    // Validar se os campos não estão vazios antes de prosseguir
    if (empty($nome) || empty($email) || empty($mensagem)) {
        echo "<p>Por favor, preencha todos os campos do formulário.</p>";
    } else {
        // Preparar a consulta SQL usando instruções preparadas para evitar SQL injection
        $sql = "INSERT INTO `contato`(`nome`, `email`, `mensagem`) VALUES (:nome, :email, :mensagem)";
        $inserir = $pdo->prepare($sql);

        // Bind dos parâmetros
        $inserir->bindParam(':nome', $nome, PDO::PARAM_STR);
        $inserir->bindParam(':email', $email, PDO::PARAM_STR);
        $inserir->bindParam(':mensagem', $mensagem, PDO::PARAM_STR);

        // Executar a consulta
        $inserir->execute();

        // Redirecionar para a página de confirmação
        header("Location: confirmacao.php");
        exit(); // Certifique-se de encerrar a execução após o redirecionamento
    }
}

?>

<main>
    <h1>Entre em Contato:</h1>
    <form name="form1" method="post">

        <label for="nome">Seu nome:</label>
        <input type="text" name="nome" id="nome" required>
        <br>
        <label for="email">Seu e-mail:</label>
        <input type="text" name="email" id="email" required>
        <br>
        <label for="mensagem">Sua mensagem:</label>
        <textarea name="mensagem" rows="5" required></textarea>
        <br>
        <button type="submit">Enviar Mensagem</button>

    </form>
</main>

<?php
include "footer.php";
?>
