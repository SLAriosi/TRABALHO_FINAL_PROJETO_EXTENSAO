<?php
include "header.php"; 
?>

<div class="enviodeformulario formularioenvio">
    <h1 class="formularioenvio">Formulário Enviado com Sucesso!</h1>
    <p class="formularioenvio">Obrigado por entrar em contato. Recebemos sua mensagem.</p>
    
    <a href="index.php" class="back-btn formularioenvio">Voltar para a Home</a>
</div>

<?php
include "footer.php"; 
?>