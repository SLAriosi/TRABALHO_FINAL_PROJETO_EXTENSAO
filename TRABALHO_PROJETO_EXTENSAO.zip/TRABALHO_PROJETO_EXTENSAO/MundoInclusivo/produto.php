<?php 
include "header.php";
include "config.php";

$id = $_GET["id"]; //Esse id vem da URL produto.php?id=2

    $sql = "select * from famoso where id = $id";
    $consulta = $pdo->prepare($sql);
    $consulta->execute();

    $produtos = $consulta->fetch(PDO::FETCH_ASSOC);
    //print_r($produtos);exit;
?>
<main>
    <div class="grid3">
        <div class="coluna3">
            <img src="imagens/<?=$produtos["imagem"]?>" alt="<?=$produtos["nome"]?>">
        </div>
        <div class="coluna4">
            <h2><?=$produtos["nome"]?></h2>
            <p><?=$produtos["descricao"]?></p>
        </div>
    </div>
</main>


<?php 
include "footer.php";
?>